import dotenv from "dotenv";

//loads all the env variables in the application
dotenv.config();
